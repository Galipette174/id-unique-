CREATE TABLE IF NOT EXISTS player_uids (
  uid INT NOT NULL AUTO_INCREMENT,
  license VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (uid),
  UNIQUE KEY uq_license (license)
);

CREATE TABLE IF NOT EXISTS bans (
  id INT NOT NULL AUTO_INCREMENT,
  uid INT NOT NULL,
  reason VARCHAR(255),
  banned_by VARCHAR(64),
  expires_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_uid (uid)
);

-- (optionnel) indexes perf
-- ALTER TABLE bans ADD INDEX idx_uid_created (uid, created_at);
-- ALTER TABLE bans ADD INDEX idx_expires (expires_at);
