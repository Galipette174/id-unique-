--========================================================
-- uid_core (framework agnostic)
-- UID permanent lié à la license + commandes admin + ban/tempban offline
-- Logs Discord (optionnel)
--========================================================

--======== CONFIG ========--
local WEBHOOK_URL = "" -- Mets ton webhook Discord ici (laisser vide = pas de logs)

-- Permissions ACE (recommandé):
-- add_ace group.admin uid.admin allow
local ADMIN_ACE = "uid.admin"

--======== INTERNAL ========--
local UIDBySource = {}
local SourceByUID = {}

local function IsAdmin(src)
  if src == 0 then return true end -- console
  return IsPlayerAceAllowed(src, ADMIN_ACE)
end

local function SendDiscordLog(title, description, color)
  if WEBHOOK_URL == nil or WEBHOOK_URL == "" then return end
  local payload = {
    username = "uid_core",
    embeds = {{
      title = title,
      description = description,
      color = color or 16777215,
      footer = { text = "uid_core" }
    }}
  }
  PerformHttpRequest(WEBHOOK_URL, function() end, "POST", json.encode(payload), { ["Content-Type"] = "application/json" })
end

local function Chat(src, msg)
  TriggerClientEvent("chat:addMessage", src, { args = { "SYSTEM", msg } })
end

local function GetLicense(src)
  for _, id in ipairs(GetPlayerIdentifiers(src)) do
    if id:sub(1, 8) == "license:" or id:sub(1, 9) == "license2:" then
      return id
    end
  end
  return nil
end

local function EnsureUID(src)
  local license = GetLicense(src)
  if not license then return nil, "NO_LICENSE" end

  local row = MySQL.single.await("SELECT uid FROM player_uids WHERE license = ?", { license })
  if row and row.uid then return tonumber(row.uid) end

  local uid = MySQL.insert.await("INSERT INTO player_uids (license) VALUES (?)", { license })
  return tonumber(uid)
end

local function UIDExists(uid)
  local row = MySQL.single.await("SELECT uid FROM player_uids WHERE uid = ? LIMIT 1", { tonumber(uid) })
  return row ~= nil
end

local function GetUIDInfo(uid)
  return MySQL.single.await("SELECT uid, license, created_at FROM player_uids WHERE uid = ? LIMIT 1", { tonumber(uid) })
end

local function GetActiveBan(uid)
  return MySQL.single.await([[
    SELECT id, reason, banned_by, expires_at, created_at
    FROM bans
    WHERE uid = ?
      AND (expires_at IS NULL OR expires_at > NOW())
    ORDER BY id DESC
    LIMIT 1
  ]], { tonumber(uid) })
end

--======== EXPORTS ========--
exports("GetUIDFromSource", function(src) return UIDBySource[src] end)
exports("GetSourceFromUID", function(uid) return SourceByUID[tonumber(uid)] end)

exports("ResolveTarget", function(arg)
  local n = tonumber(arg)
  if not n then return nil, nil, "INVALID_ARG" end

  if GetPlayerName(n) then
    return n, UIDBySource[n], nil
  end

  local src = SourceByUID[n]
  if src and GetPlayerName(src) then
    return src, n, nil
  end

  return nil, n, "NOT_ONLINE"
end)

--======== CONNECTION HOOK ========--
AddEventHandler("playerConnecting", function(_, _, deferrals)
  local src = source
  deferrals.defer()
  Wait(0)

  deferrals.update("Chargement de votre identifiant...")

  local uid = EnsureUID(src)
  if not uid then
    deferrals.done("Erreur: impossible de récupérer votre UID (license manquante).")
    return
  end

  local ban = GetActiveBan(uid)
  if ban then
    if ban.expires_at == nil then
      deferrals.done(("Banni (permanent). Raison: %s"):format(ban.reason or "N/A"))
    else
      deferrals.done(("Banni jusqu'au %s. Raison: %s"):format(tostring(ban.expires_at), ban.reason or "N/A"))
    end
    return
  end

  UIDBySource[src] = uid
  SourceByUID[uid] = src

  deferrals.done()
end)

AddEventHandler("playerDropped", function()
  local src = source
  local uid = UIDBySource[src]
  UIDBySource[src] = nil
  if uid and SourceByUID[uid] == src then SourceByUID[uid] = nil end
end)

AddEventHandler("onResourceStart", function(resName)
  if resName ~= GetCurrentResourceName() then return end
  for _, s in ipairs(GetPlayers()) do
    local src = tonumber(s)
    if src then
      local uid = EnsureUID(src)
      if uid then
        UIDBySource[src] = uid
        SourceByUID[uid] = src
      end
    end
  end
end)

--======== COMMANDES ========--

-- /uid | /uid <idServeur> | /uid <uid>
RegisterCommand("uid", function(src, args)
  local arg = args[1]

  if not arg then
    local uid = UIDBySource[src]
    if not uid then
      uid = EnsureUID(src)
      if uid then
        UIDBySource[src] = uid
        SourceByUID[uid] = src
      end
    end
    if not uid then Chat(src, "UID introuvable (license manquante ou DB).") return end
    Chat(src, ("Votre UID unique est : ^2%s^7"):format(uid))
    SendDiscordLog("UID consulté", ("**%s** (%s) a consulté son UID: **%s**"):format(GetPlayerName(src) or "?", src, uid), 65280)
    return
  end

  local n = tonumber(arg)
  if not n then Chat(src, "Usage: /uid ou /uid <id|uid>") return end

  if GetPlayerName(n) then
    local uid = UIDBySource[n]
    if not uid then
      uid = EnsureUID(n)
      if uid then
        UIDBySource[n] = uid
        SourceByUID[uid] = n
      end
    end
    if not uid then Chat(src, "UID introuvable pour ce joueur.") return end
    Chat(src, ("Joueur ^3%s^7 | ID: ^3%s^7 | UID: ^2%s^7"):format(GetPlayerName(n), n, uid))
    SendDiscordLog("UID lookup (par ID)", ("**%s** (%s) a demandé l'UID de **%s** (%s) -> UID **%s**"):format(
      GetPlayerName(src) or "?", src, GetPlayerName(n) or "?", n, uid
    ), 3447003)
    return
  end

  local targetSrc = SourceByUID[n]
  if targetSrc and GetPlayerName(targetSrc) then
    Chat(src, ("UID ^2%s^7 appartient à ^3%s^7 (ID serveur: ^3%s^7)"):format(n, GetPlayerName(targetSrc), targetSrc))
    SendDiscordLog("UID lookup (par UID)", ("**%s** (%s) a recherché UID **%s** -> **%s** (%s)"):format(
      GetPlayerName(src) or "?", src, n, GetPlayerName(targetSrc) or "?", targetSrc
    ), 3447003)
  else
    Chat(src, ("UID ^2%s^7 : joueur hors-ligne ou introuvable."):format(n))
    SendDiscordLog("UID lookup (offline)", ("**%s** (%s) a recherché UID **%s** -> hors-ligne/introuvable"):format(
      GetPlayerName(src) or "?", src, n
    ), 16753920)
  end
end, false)

-- /uidreload (admin)
RegisterCommand("uidreload", function(src)
  if not IsAdmin(src) then if src ~= 0 then Chat(src, "Permission refusée.") end return end
  local count = 0
  for _, s in ipairs(GetPlayers()) do
    local p = tonumber(s)
    if p then
      local uid = EnsureUID(p)
      if uid then
        UIDBySource[p] = uid
        SourceByUID[uid] = p
        count = count + 1
      end
    end
  end
  if src ~= 0 then Chat(src, ("Cache UID rechargé (%s joueurs)."):format(count)) end
  SendDiscordLog("UID reload", ("**%s** (%s) a rechargé le cache UID (%s joueurs)."):format(GetPlayerName(src) or "CONSOLE", src, count), 10181046)
end, false)

-- /uidinfo <uid> (admin)
RegisterCommand("uidinfo", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local uid = tonumber(args[1])
  if not uid then Chat(src, "Usage: /uidinfo <uid>") return end
  local info = GetUIDInfo(uid)
  if not info then Chat(src, "UID introuvable en base.") return end
  Chat(src, ("UID: ^2%s^7 | License: ^3%s^7 | Créé: ^3%s^7"):format(info.uid, info.license, tostring(info.created_at)))
  SendDiscordLog("UID info", ("**%s** (%s) a consulté uidinfo **%s**\nLicense: %s\nCréé: %s"):format(
    GetPlayerName(src) or "?", src, info.uid, info.license, tostring(info.created_at)
  ), 10181046)
end, false)

-- /checkban <uid> (admin)
RegisterCommand("checkban", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local uid = tonumber(args[1])
  if not uid then Chat(src, "Usage: /checkban <uid>") return end
  local ban = GetActiveBan(uid)
  if not ban then Chat(src, ("UID ^2%s^7 n'est pas banni."):format(uid)) return end
  if ban.expires_at == nil then
    Chat(src, ("UID ^2%s^7 banni (permanent). Raison: ^3%s^7"):format(uid, ban.reason or "N/A"))
  else
    Chat(src, ("UID ^2%s^7 banni jusqu'au ^3%s^7. Raison: ^3%s^7"):format(uid, tostring(ban.expires_at), ban.reason or "N/A"))
  end
  SendDiscordLog("Check ban", ("**%s** (%s) a checkban UID **%s**\nRaison: %s\nExpire: %s"):format(
    GetPlayerName(src) or "?", src, uid, ban.reason or "N/A", tostring(ban.expires_at)
  ), 16753920)
end, false)

-- /whois <id|uid> (admin)
RegisterCommand("whois", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local arg = args[1]
  if not arg then Chat(src, "Usage: /whois <id|uid>") return end

  local targetSrc, uid, _ = exports.uid_core:ResolveTarget(arg)
  uid = tonumber(uid)
  if targetSrc and (uid == nil or uid == 0) then
    uid = EnsureUID(targetSrc)
    if uid then UIDBySource[targetSrc] = uid; SourceByUID[uid] = targetSrc end
  end
  if not uid then Chat(src, "Cible invalide.") return end

  local onlineText, nameText, idText = "OFFLINE", "N/A", "N/A"
  if targetSrc and GetPlayerName(targetSrc) then
    onlineText, nameText, idText = "ONLINE", GetPlayerName(targetSrc), tostring(targetSrc)
  end

  local ban = GetActiveBan(uid)
  local banText = "Aucun ban actif"
  if ban then
    if ban.expires_at == nil then banText = "BAN PERMA | " .. (ban.reason or "N/A")
    else banText = "TEMPBAN jusqu'au " .. tostring(ban.expires_at) .. " | " .. (ban.reason or "N/A") end
  end

  Chat(src, ("WHOIS -> UID:^2 %s ^7| %s | Nom:^3 %s ^7| ID:^3 %s ^7| %s"):format(uid, onlineText, nameText, idText, banText))
  SendDiscordLog("WHOIS", ("**%s** (%s) a whois **%s**\nStatus: %s\nNom: %s\nID: %s\nBan: %s"):format(
    GetPlayerName(src) or "?", src, uid, onlineText, nameText, idText, banText
  ), 10181046)
end, false)

-- /banuid <uid> [raison] (admin)
RegisterCommand("banuid", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local uid = tonumber(args[1])
  local reason = table.concat(args, " ", 2)
  if not uid then Chat(src, "Usage: /banuid <uid> [raison]") return end
  if not UIDExists(uid) then Chat(src, ("UID %s introuvable en base."):format(uid)) return end
  reason = (reason ~= "" and reason) or "Aucune raison"

  MySQL.insert.await("INSERT INTO bans (uid, reason, banned_by) VALUES (?, ?, ?)", { uid, reason, tostring(src) })

  local online = SourceByUID[uid]
  if online and GetPlayerName(online) then DropPlayer(online, "Vous êtes banni. Raison: " .. reason) end

  Chat(src, ("Banni UID ^2%s^7."):format(uid))
  SendDiscordLog("Ban permanent", ("**%s** (%s) a banni UID **%s**\nRaison: %s"):format(GetPlayerName(src) or "CONSOLE", src, uid, reason), 16711680)
end, false)

-- /permbanuid alias
RegisterCommand("permbanuid", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  if not args[1] then Chat(src, "Usage: /permbanuid <uid> [raison]") return end
  ExecuteCommand(("banuid %s %s"):format(args[1], table.concat(args, " ", 2)))
end, false)

-- /tempbanuid <uid> <minutes> [raison] (admin)
RegisterCommand("tempbanuid", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local uid = tonumber(args[1])
  local minutes = tonumber(args[2])
  local reason = table.concat(args, " ", 3)
  if not uid or not minutes or minutes <= 0 then Chat(src, "Usage: /tempbanuid <uid> <minutes> [raison]") return end
  if not UIDExists(uid) then Chat(src, ("UID %s introuvable en base."):format(uid)) return end
  reason = (reason ~= "" and reason) or "Aucune raison"

  MySQL.insert.await([[
    INSERT INTO bans (uid, reason, banned_by, expires_at)
    VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE))
  ]], { uid, reason, tostring(src), minutes })

  local online = SourceByUID[uid]
  if online and GetPlayerName(online) then
    DropPlayer(online, ("Vous êtes banni %d minute(s). Raison: %s"):format(minutes, reason))
  end

  Chat(src, ("Tempban UID ^2%s^7 pour ^3%s^7 minute(s)."):format(uid, minutes))
  SendDiscordLog("Tempban", ("**%s** (%s) a tempban UID **%s** pour **%s** minute(s)\nRaison: %s"):format(
    GetPlayerName(src) or "CONSOLE", src, uid, minutes, reason
  ), 16753920)
end, false)

-- /unbanuid <uid> (admin)
RegisterCommand("unbanuid", function(src, args)
  if not IsAdmin(src) then Chat(src, "Permission refusée.") return end
  local uid = tonumber(args[1])
  if not uid then Chat(src, "Usage: /unbanuid <uid>") return end
  MySQL.query.await("DELETE FROM bans WHERE uid = ?", { uid })
  Chat(src, ("Unban UID ^2%s^7."):format(uid))
  SendDiscordLog("Unban", ("**%s** (%s) a unban UID **%s**"):format(GetPlayerName(src) or "CONSOLE", src, uid), 65280)
end, false)
