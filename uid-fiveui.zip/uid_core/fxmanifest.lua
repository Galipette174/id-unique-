fx_version 'cerulean'
game 'gta5'

author 'uid_core'
description 'UID permanent + admin commands + ban/tempban offline (framework agnostic)'
version '1.2.0'

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server.lua'
}
